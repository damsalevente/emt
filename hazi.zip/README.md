# Motor mágneses terének intenzitás
